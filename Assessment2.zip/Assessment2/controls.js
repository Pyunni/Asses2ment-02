var preview = document.getElementById("preview"),
    display = document.getElementById("display"),
    random = document.getElementById("random"),
    range1 = document.getElementById("range1"),
    range2 = document.getElementById("range2"),
    range3 = document.getElementById("range3"),
    range4 = document.getElementById("range4"),
    hair = document.getElementById("hair"),
    eyes = document.getElementById("eyes"),
    nose = document.getElementById("nose"),
    mouth = document.getElementById("mouth"),
    plus = document.getElementById("plus");

var hairArr = ["img/hair1.png", "img/hair2.png", "img/hair3.png"];
var eyesArr = ["img/eyes1.png", "img/eyes2.png", "img/eyes3.png"];
var noseArr = ["img/nose1.png", "img/nose2.png", "img/nose3.png"];
var mouthArr = ["img/mouth1.png", "img/mouth2.png", "img/mouth3.png"];


document.getElementById("color").addEventListener("change", function(){
    preview.style.backgroundColor ="beige";
});

random.addEventListener("click", function(){
    randomMake();
});

function createFace(){
    var ndiv = document.createElement("div"),
        nimg = document.createElement("nimg");
    
    nimg.src = preview;
    
    ndiv.className = "bags";
    nimg.classname = "bagImg";
    
    ndiv.appendChild(nimg);
    
    display.appendChild(ndiv);
};

function randomMake() {
    var num = Math.floor(Math.random() * 2);
    
    document.hair.src = hairArr[num];
    document.eyes.src = eyesArr[num];
    document.nose.src = noseArr[num];
    document.mouth.src = mouthArr[num];
    document.preview.src = num;
};

function changeType(type) {
    range1.addEventListener("change", function(){
    document.getElementById("hair").style.width = range1.value + "%";
}); 

range2.addEventListener("change", function(){
    document.getElementById("eyes").style.width = range2.value + "%";
});

range3.addEventListener("change", function(){
    document.getElementById("nose").style.width = range3.value + "%";
});

range4.addEventListener("change", function(){
    document.getElementById("mouth").style.width = range4.value + "%";
});
};

function changeType("Number") {
    
document.getElementById("number").addEventListener("click", function(){
    range1.type = 'number';
    range2.type = 'number';
    range3.type = 'number';
    range4.type = 'number';
});
};

function changeType("range") {
    document.getElementById("range").addEventListener("click", function(){
    range1.type = 'range';
    range2.type = 'range';
    range3.type = 'range';
    range4.type = 'range';
});
};

document.getElementById("auto").addEventListener("click", function(){
    var spd = document.getElementById("speed").value;
    
    setInterval(function(){
    var newDiv = document.createElement("div");
    document.body.appendChild(newDiv);
    newDiv.className = "fast";
    newDiv.id = "faster" +num;
    num++;

    var w = 10;
    var h = 10;
           
    newDiv.style.backgroundColor = "rgb("+r+","+g+","+b+")";
    
    newDiv.style.width = w+"px";
    newDiv.style.height = h+"px";
    
    }, spd);
});

document.getElementById("stop").addEventListener("click", function(){
    document.body.removeChild(display);
    display = document.createElement("div");
    dispDiv.id = "display";
    document.body.appendChild(display);
});