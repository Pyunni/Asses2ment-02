/*============DO NOT TOUCH THESE======================*/
var hair = document.getElementById("hair"),
    eyes = document.getElementById("eyes"),
    nose = document.getElementById("nose"),
    mouth = document.getElementById("mouth");

hair.style.width = "60%";
hair.style.top = "0%";
eyes.style.width = "20%";
eyes.style.top = "40%";
nose.style.width = "20%";
nose.style.top = "55%";
mouth.style.width = "20%";
mouth.style.top = "75%";

/*==================YOUR WORK STARTS BELOW=====================*/

function changeHair() {
    var image = document.getElementById("hair");
    
     if (image.getAttribute('src') == "img/hair1.png") {
         image.src = "img/hair3.png";
     } else {
     image.src = "img/hair1.png";
     }
    if (image.getAttribute('src') == "img/hair3.png") {
        image.src = "img/hair2.png";
    } else {
        image.src = "img/hair3.png";
    }
    };
function changeEyes() {
    var image = document.getElementById("eyes");
    
     if (image.getAttribute('src') == "img/eyes1.png") {
         image.src = "img/eyes3.png";
     } else {
     image.src = "img/eyes1.png";
     }
    if (image.getAttribute('src') == "img/eyes3.png") {
        image.src = "img/eyes2.png";
    } else {
        image.src = "img/eyes3.png";
    }
    };
function changeNose() {
    var image = document.getElementById("nose");
    
     if (image.getAttribute('src') == "img/nose1.png") {
         image.src = "img/nose3.png";
     } else {
     image.src = "img/nose1.png";
     }
    if (image.getAttribute('src') == "img/nose3.png") {
        image.src = "img/nose2.png";
    } else {
        image.src = "img/nose3.png";
    }
    };
function changeMouth() {
    var image = document.getElementById("mouth");
    
     if (image.getAttribute('src') == "img/mouth1.png") {
         image.src = "img/mouth3.png";
     } else {
     image.src = "img/mouth1.png";
     }
    if (image.getAttribute('src') == "img/mouth3.png") {
        image.src = "img/mouth2.png";
    } else {
        image.src = "img/mouth3.png";
    }
    };
